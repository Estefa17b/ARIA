import { useState, useEffect, useRef, useCallback } from "react";
import {
  AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";

// ─── Assets ──────────────────────────────────────────────────────────────────
const ASSET_GROUPS = {
  Crypto: [
    { id:"BTCUSDT", label:"BTC/USDT", name:"Bitcoin",  icon:"₿", ws:true },
    { id:"ETHUSDT", label:"ETH/USDT", name:"Ethereum", icon:"Ξ", ws:true },
    { id:"SOLUSDT", label:"SOL/USDT", name:"Solana",   icon:"◎", ws:true },
  ],
  Forex: [
    { id:"EURUSD", label:"EUR/USD", name:"Euro / Dollar",  icon:"€", ws:false, base:1.085 },
    { id:"GBPUSD", label:"GBP/USD", name:"Pound / Dollar", icon:"£", ws:false, base:1.265 },
    { id:"USDJPY", label:"USD/JPY", name:"Dollar / Yen",   icon:"¥", ws:false, base:149.5 },
  ],
  Equities: [
    { id:"SPX", label:"S&P 500", name:"S&P 500 Index", icon:"📈", ws:false, base:5270 },
    { id:"NDX", label:"NASDAQ",  name:"Nasdaq 100",    icon:"⬡",  ws:false, base:18400 },
  ],
  Commodities: [
    { id:"XAUUSD", label:"XAU/USD", name:"Gold / Dollar", icon:"Au", ws:false, base:2320 },
    { id:"WTIUSD", label:"WTI Oil", name:"Crude Oil WTI", icon:"🛢", ws:false, base:78.4 },
  ],
};

const ALL_ASSETS   = Object.values(ASSET_GROUPS).flat();
const LEVERAGE_OPS = [1, 2, 3, 5, 10, 20, 50];
const WS_BASE      = "wss://stream.binance.com:9443/ws";

// ─── Helpers ──────────────────────────────────────────────────────────────────
const fmt   = (n, d = 2) => Number(n).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const fmtTS = () => new Date().toLocaleString("en-US", { month:"short", day:"numeric", hour:"2-digit", minute:"2-digit" });
const fmtCD = s => `${String(Math.floor(s / 60)).padStart(2,"0")}:${String(s % 60).padStart(2,"0")}`;

// ─── Indicators ───────────────────────────────────────────────────────────────
function calcRSI(closes, p = 14) {
  if (closes.length < p + 1) return null;
  let g = 0, l = 0;
  for (let i = closes.length - p; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) g += d; else l -= d;
  }
  const ag = g / p, al = l / p;
  return al === 0 ? 100 : 100 - 100 / (1 + ag / al);
}
function ema(arr, p) {
  const k = 2 / (p + 1); let e = arr[0];
  for (let i = 1; i < arr.length; i++) e = arr[i] * k + e * (1 - k);
  return e;
}
function calcMACD(closes) {
  if (closes.length < 26) return { macd: null, signal: null };
  const m = ema(closes.slice(-26), 12) - ema(closes, 26);
  return { macd: +m.toFixed(6), signal: +(m * 0.9).toFixed(6) };
}

// ─── Simulated data ───────────────────────────────────────────────────────────
function simKlines(base, n = 48) {
  let v = base;
  return Array.from({ length: n }, (_, i) => {
    const o = v;
    v = Math.max(base * 0.7, v * (1 + (Math.random() - 0.49) * 0.006));
    const h = Math.max(o, v) * (1 + Math.random() * 0.004);
    const l = Math.min(o, v) * (1 - Math.random() * 0.004);
    const d = new Date(); d.setHours(d.getHours() - (n - i));
    return {
      time: `${d.getHours().toString().padStart(2,"0")}:00`,
      open: o, high: h, low: l, close: v,
      volume: Math.random() * 4e8 + 5e7, value: v,
    };
  });
}
function simTick(base) {
  const price = base * (1 + (Math.random() - 0.5) * 0.008);
  return { price, ch24: (Math.random() - 0.45) * 2.5, high24: price * 1.01, low24: price * 0.99, vol24: price * Math.random() * 1e6 };
}

// ─── Color palette ────────────────────────────────────────────────────────────
const palette = dark => dark ? {
  bg:"#080d18", surface:"#0e1525", card:"#111e30", border:"#192840",
  muted:"#1e304a", subtle:"#4a6585", text:"#b5cde0", heading:"#eaf2fa",
  accent:"#2563eb", accentBg:"rgba(37,99,235,0.11)",
  long:"#10b981", short:"#ef4444", wait:"#f59e0b",
  shadow:"0 4px 32px rgba(0,0,0,0.55)", card2:"0 2px 8px rgba(0,0,0,0.35)",
} : {
  bg:"#f0f4fb", surface:"#ffffff", card:"#ffffff", border:"#e0e8f4",
  muted:"#dce6f5", subtle:"#7a9abf", text:"#2d4a68", heading:"#091929",
  accent:"#1d4ed8", accentBg:"rgba(29,78,216,0.07)",
  long:"#059669", short:"#dc2626", wait:"#b45309",
  shadow:"0 4px 28px rgba(9,25,41,0.10)", card2:"0 1px 4px rgba(9,25,41,0.07)",
};

// ─── Chart Tooltip ────────────────────────────────────────────────────────────
const CTip = ({ active, payload, label, C, isPrice, dp = 2 }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:8, padding:"8px 14px", boxShadow:C.shadow }}>
      <p style={{ fontSize:10, color:C.subtle, marginBottom:2 }}>{label}</p>
      <p style={{ fontSize:13, fontWeight:700, color:C.heading, fontFamily:"'DM Mono'" }}>
        {isPrice ? "$" : ""}{fmt(payload[0].value, isPrice ? dp : 0)}
      </p>
    </div>
  );
};

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [dark, setDark]           = useState(false);
  const [lang, setLang]           = useState("es");
  const [asset, setAsset]         = useState(ALL_ASSETS[0]);
  const [tab, setTab]             = useState("dashboard");
  const [ticker, setTicker]       = useState(null);
  const [klines, setKlines]       = useState([]);
  const [wsStatus, setWsStatus]   = useState("connecting");
  const [rsi, setRsi]             = useState(null);
  const [macd, setMacd]           = useState({});
  const [signal, setSignal]       = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [history, setHistory]     = useState([]);
  const [capital, setCapital]     = useState(1000);
  const [capInput, setCapInput]   = useState("1000");
  const [leverage, setLeverage]   = useState(null);
  const [autoOn, setAutoOn]       = useState(false);
  const [countdown, setCd]        = useState(3600);
  const [mobileOpen, setMobileOpen] = useState(false);

  const wsRef  = useRef(null);
  const cdRef  = useRef(null);
  const klRef  = useRef([]);
  const C = palette(dark);

  const recompute = useCallback((kl) => {
    const closes = kl.map(k => k.close);
    setRsi(calcRSI(closes));
    setMacd(calcMACD(closes));
  }, []);

  // ── Connect WebSocket or simulate ─────────────────────────────────────────
  const connectWS = useCallback((a) => {
    if (wsRef.current) {
      if (wsRef.current._sim) { clearInterval(wsRef.current._iv); }
      else { try { wsRef.current.close(1000); } catch {} }
      wsRef.current = null;
    }

    if (!a.ws) {
      const kl = simKlines(a.base);
      klRef.current = kl;
      setKlines([...kl]);
      setTicker(simTick(a.base));
      recompute(kl);
      setWsStatus("sim");
      const iv = setInterval(() => {
        const t = simTick(a.base);
        setTicker(t);
        const now = new Date();
        const bar = {
          time: `${now.getHours().toString().padStart(2,"0")}:${now.getMinutes().toString().padStart(2,"0")}`,
          open: klRef.current.at(-1)?.close ?? t.price,
          high: t.price * 1.002, low: t.price * 0.998,
          close: t.price, volume: Math.random() * 2e8 + 3e7, value: t.price,
        };
        if (klRef.current.at(-1)?.time === bar.time) {
          klRef.current = [...klRef.current.slice(0,-1), bar];
        } else {
          klRef.current = [...klRef.current.slice(-47), bar];
        }
        setKlines([...klRef.current]);
        recompute(klRef.current);
      }, 4000);
      wsRef.current = { _sim: true, _iv: iv };
      return;
    }

    setWsStatus("connecting");
    const sym = a.id.toLowerCase();
    let ws;
    try { ws = new WebSocket(`${WS_BASE}/${sym}@miniTicker/${sym}@kline_1h`); }
    catch { setWsStatus("error"); return; }

    ws.onopen  = () => setWsStatus("live");
    ws.onerror = () => setWsStatus("error");
    ws.onclose = (e) => { if (e.code !== 1000) setWsStatus("error"); };
    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data);
        if (msg.e === "24hrMiniTicker") {
          setTicker({
            price: +msg.c,
            ch24: ((+msg.c - +msg.o) / +msg.o) * 100,
            high24: +msg.h, low24: +msg.l, vol24: +msg.q,
          });
        }
        if (msg.e === "kline") {
          const k = msg.k;
          const bar = {
            time: new Date(k.t).toLocaleTimeString("en-US", { hour:"2-digit", minute:"2-digit" }),
            open:+k.o, high:+k.h, low:+k.l, close:+k.c, volume:+k.v, value:+k.c,
          };
          if (klRef.current.at(-1)?.time === bar.time) {
            klRef.current = [...klRef.current.slice(0,-1), bar];
          } else {
            klRef.current = [...klRef.current.slice(-47), bar];
          }
          setKlines([...klRef.current]);
          recompute(klRef.current);
        }
      } catch {}
    };
    wsRef.current = ws;
  }, [recompute]);

  // ── Bootstrap Binance: REST history + WS live ─────────────────────────────
  const bootstrapBinance = useCallback(async (a) => {
    setWsStatus("connecting");
    setKlines([]); setTicker(null); klRef.current = [];
    try {
      const [klRes, tkRes] = await Promise.all([
        fetch(`https://api.binance.com/api/v3/klines?symbol=${a.id}&interval=1h&limit=48`),
        fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${a.id}`),
      ]);
      const raw = await klRes.json();
      const kl = raw.map(k => ({
        time: new Date(k[0]).toLocaleTimeString("en-US", { hour:"2-digit", minute:"2-digit" }),
        open:+k[1], high:+k[2], low:+k[3], close:+k[4], volume:+k[5], value:+k[4],
      }));
      klRef.current = kl;
      setKlines(kl);
      recompute(kl);
      const tk = await tkRes.json();
      setTicker({ price:+tk.lastPrice, ch24:+tk.priceChangePercent, high24:+tk.highPrice, low24:+tk.lowPrice, vol24:+tk.quoteVolume });
    } catch {
      // Fallback to placeholder while WS loads
      const kl = simKlines(65000);
      klRef.current = kl;
      setKlines(kl);
      recompute(kl);
    }
    connectWS(a);
  }, [connectWS, recompute]);

  useEffect(() => {
    if (asset.ws) { bootstrapBinance(asset); }
    else { connectWS(asset); }
    return () => {
      if (wsRef.current) {
        if (wsRef.current._sim) { clearInterval(wsRef.current._iv); }
        else { try { wsRef.current.close(1000); } catch {} }
        wsRef.current = null;
      }
    };
  }, [asset]); // eslint-disable-line

  // ── Auto countdown ────────────────────────────────────────────────────────
  useEffect(() => {
    clearInterval(cdRef.current);
    if (!autoOn) { setCd(3600); return; }
    setCd(3600);
    cdRef.current = setInterval(() => {
      setCd(n => { if (n <= 1) { runSignal(); return 3600; } return n - 1; });
    }, 1000);
    return () => clearInterval(cdRef.current);
  }, [autoOn, asset]); // eslint-disable-line

  // ── AI Signal ─────────────────────────────────────────────────────────────
  const runSignal = async () => {
    if (!ticker) return;
    setAnalyzing(true); setSignal(null);
    const { price, ch24, high24, low24 } = ticker;
    const closes  = klines.map(k => k.close);
    const vols    = klines.map(k => k.volume);
    const avgVol  = vols.reduce((a, b) => a + b, 0) / (vols.length || 1);
    const volRatio = ((vols.at(-1) || 0) / avgVol).toFixed(2);
    const dp = price > 100 ? 2 : price > 1 ? 4 : 6;

    const histCtx = history.slice(-5).map(s =>
      `[${s.time}] ${s.signal} @$${s.priceAtSignal} → conf ${s.confidence}%`
    ).join("\n") || "Sin señales previas esta sesión.";

    const prompt = `Eres ARIA, agente cuantitativo de trading IA. Analiza ${asset.label} (${asset.name}) con datos reales y genera señal horaria completa.

DATOS DE MERCADO EN TIEMPO REAL:
- Precio: $${fmt(price, dp)}
- Cambio 24h: ${ch24 >= 0 ? "+" : ""}${ch24.toFixed(3)}%
- Máx/Mín 24h: $${fmt(high24, dp)} / $${fmt(low24, dp)}
- RSI(14): ${rsi ? rsi.toFixed(2) : "N/D"}
- MACD: ${macd.macd ?? "N/D"} | Señal MACD: ${macd.signal ?? "N/D"}
- Ratio volumen vs media 48h: ${volRatio}x
- Máx 48h: $${closes.length ? fmt(Math.max(...closes), dp) : "N/D"}
- Mín 48h: $${closes.length ? fmt(Math.min(...closes), dp) : "N/D"}
- Capital: $${fmt(capital, 2)} | Apalancamiento máx permitido: 50x

HISTORIAL DE SEÑALES (aprendizaje continuo):
${histCtx}

Analiza: RSI sobrecomprado/vendido, divergencias MACD, volumen anómalo, soportes/resistencias en rango 48h, estructura de mercado. Aprende del historial para mejorar precisión.

Responde ÚNICAMENTE con JSON válido sin backticks ni texto extra:
{
  "signal": "LONG" | "SHORT" | "ESPERAR",
  "confidence": <40-95>,
  "leverage": <número de [1,2,3,5,10,20,50] máx 50>,
  "leverageRationale": "<justificación del nivel de apalancamiento>",
  "entry": <precio de entrada>,
  "stopLoss": <precio stop-loss>,
  "takeProfit": <precio take-profit>,
  "riskRewardRatio": <número decimal>,
  "capitalToRisk": <1-10>,
  "positionSize": <capital * leverage * capitalToRisk / 100>,
  "summary": "<3 oraciones de análisis técnico profesional>",
  "technicalBasis": "<RSI, MACD y volumen interpretados con valores exactos>",
  "keyLevels": ["<soporte1>", "<soporte2>", "<resistencia1>"],
  "marketStructure": "alcista" | "bajista" | "lateral",
  "learningNote": "<qué se aprendió del historial y cómo mejora esta señal>",
  "warning": "<riesgo principal a vigilar>",
  "timeframe": "1H"
}`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1200,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      const data   = await res.json();
      const raw    = data.content?.map(b => b.text || "").join("") || "";
      const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
      const entry  = { ...parsed, priceAtSignal: fmt(price, dp), time: fmtTS(), asset: asset.label };
      setSignal(entry);
      setLeverage(parsed.leverage);
      setHistory(prev => [...prev.slice(-19), entry]);
    } catch { setSignal({ error: true }); }
    setAnalyzing(false);
  };

  const sigColor = s => {
    if (!s) return C.accent;
    if (s === "LONG")    return C.long;
    if (s === "SHORT")   return C.short;
    return C.wait;
  };

  const price = ticker?.price ?? 0;
  const ch24  = ticker?.ch24  ?? 0;
  const isUp  = ch24 >= 0;
  const dp    = price > 100 ? 2 : price > 1 ? 4 : 6;

  const statusLabel = { connecting:"Conectando…", live:"EN VIVO · Binance", sim:"Simulado", error:"Sin conexión" }[wsStatus];
  const statusColor = { connecting:C.wait, live:C.long, sim:C.subtle, error:C.short }[wsStatus];

  // ── Sidebar ───────────────────────────────────────────────────────────────
  const SidebarContent = () => (
    <>
      <div style={{ padding:"14px 14px 10px", borderBottom:`1px solid ${C.border}` }}>
        <div style={{ fontSize:9, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:C.subtle, marginBottom:12 }}>
          {lang === "es" ? "Activos" : "Assets"}
        </div>
        {Object.entries(ASSET_GROUPS).map(([group, items]) => (
          <div key={group} style={{ marginBottom:14 }}>
            <div style={{ fontSize:9, color:C.subtle, letterSpacing:1.2, textTransform:"uppercase", marginBottom:6, fontWeight:600 }}>{group}</div>
            {items.map(a => (
              <div key={a.id} className="mcard"
                onClick={() => { setAsset(a); setSignal(null); setMobileOpen(false); }}
                style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"8px 10px", borderRadius:8, marginBottom:3, cursor:"pointer",
                  background: asset.id === a.id ? C.accentBg : "transparent",
                  border: `1px solid ${asset.id === a.id ? C.accent : "transparent"}`,
                  transition:"all 0.15s" }}>
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <span style={{ fontSize:13 }}>{a.icon}</span>
                  <div>
                    <div style={{ fontSize:12, fontWeight:600, color: asset.id === a.id ? C.accent : C.heading }}>{a.label}</div>
                    <div style={{ fontSize:9, color:C.subtle }}>{a.name}</div>
                  </div>
                </div>
                {asset.id === a.id && <div style={{ width:4, height:4, borderRadius:"50%", background:C.accent }} className="pulse" />}
              </div>
            ))}
          </div>
        ))}
      </div>

      <div style={{ padding:"12px 14px 8px", borderBottom:`1px solid ${C.border}` }}>
        <div style={{ fontSize:9, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:C.subtle, marginBottom:4 }}>
          {lang === "es" ? "Historial" : "Signal History"}
        </div>
        <div style={{ fontSize:10, color:C.subtle }}>
          {history.length} {lang === "es" ? "señales esta sesión" : "signals this session"}
        </div>
      </div>

      {history.length === 0 ? (
        <div style={{ padding:"20px 16px", fontSize:11, color:C.subtle, textAlign:"center", lineHeight:1.7 }}>
          {lang === "es" ? "Sin señales aún.\nEjecuta ARIA para comenzar." : "No signals yet.\nRun ARIA to begin."}
        </div>
      ) : [...history].reverse().map((s, i) => (
        <div key={i} style={{ padding:"10px 14px", borderBottom:`1px solid ${C.border}` }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:3 }}>
            <span style={{ fontSize:11, fontWeight:700, color:sigColor(s.signal), fontFamily:"'DM Mono'" }}>{s.signal}</span>
            <span style={{ fontSize:9, color:C.subtle, fontFamily:"'DM Mono'" }}>{s.leverage}x</span>
          </div>
          <div style={{ fontSize:10, color:C.text, marginBottom:2 }}>{s.asset}</div>
          <div style={{ fontSize:9, color:C.subtle, fontFamily:"'DM Mono'", marginBottom:4 }}>${s.priceAtSignal}</div>
          <div style={{ height:2, background:C.muted, borderRadius:1 }}>
            <div style={{ height:"100%", width:`${s.confidence}%`, background:sigColor(s.signal), borderRadius:1 }} />
          </div>
          <div style={{ fontSize:9, color:C.subtle, marginTop:2 }}>{s.confidence}% conf.</div>
        </div>
      ))}
    </>
  );

  return (
    <div style={{ fontFamily:"'DM Sans', sans-serif", background:C.bg, minHeight:"100dvh", color:C.text, transition:"background 0.25s, color 0.25s" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&family=DM+Mono:wght@400;500&display=swap');
        * { box-sizing:border-box; margin:0; padding:0; }
        ::-webkit-scrollbar { width:3px; }
        ::-webkit-scrollbar-thumb { background:${C.muted}; border-radius:3px; }
        button, input { font-family:inherit; }
        input:focus { outline:none; }
        .mcard { transition:all 0.15s ease; cursor:pointer; }
        .mcard:hover { background:${C.accentBg} !important; }
        .hbtn { transition:opacity 0.15s; cursor:pointer; background:none; border:none; }
        .hbtn:hover { opacity:0.7; }
        .aibtn { transition:all 0.2s; cursor:pointer; border:none; font-family:inherit; }
        .aibtn:hover:not(:disabled) { filter:brightness(1.08); transform:translateY(-1px); }
        .aibtn:disabled { opacity:0.5; cursor:not-allowed; }
        .levbtn { transition:all 0.15s; cursor:pointer; border:none; font-family:'DM Mono', monospace; }
        .levbtn:hover { filter:brightness(1.1); }
        .ntab { background:none; border:none; cursor:pointer; transition:all 0.15s; }
        .fade { animation:fu 0.3s ease both; }
        @keyframes fu { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
        .pulse { animation:pl 2s ease-in-out infinite; }
        @keyframes pl { 0%,100% { opacity:1; } 50% { opacity:0.2; } }
        .blink { animation:bl 1s step-end infinite; }
        @keyframes bl { 0%,100% { opacity:1; } 50% { opacity:0; } }
        .spin { animation:sp 1s linear infinite; }
        @keyframes sp { to { transform:rotate(360deg); } }
        .moverlay { position:fixed; inset:0; z-index:200; overflow-y:auto; }
        @media(max-width:820px) {
          .dsidebar { display:none !important; }
          .mobham { display:flex !important; }
          .kpigrid { grid-template-columns:1fr 1fr !important; }
          .chartgrid { grid-template-columns:1fr !important; }
          .siggrid { grid-template-columns:1fr 1fr !important; }
          .levrow { flex-wrap:wrap !important; }
          .main { padding:16px !important; }
        }
        @media(max-width:500px) {
          .kpigrid { grid-template-columns:1fr !important; }
          .siggrid { grid-template-columns:1fr !important; }
        }
      `}</style>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="moverlay" style={{ background:C.surface }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 16px", borderBottom:`1px solid ${C.border}` }}>
            <Logo C={C} />
            <button className="hbtn" onClick={() => setMobileOpen(false)} style={{ fontSize:20, color:C.subtle }}>✕</button>
          </div>
          <SidebarContent />
        </div>
      )}

      {/* Header */}
      <header style={{ background:C.surface, borderBottom:`1px solid ${C.border}`, height:56, display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 20px", position:"sticky", top:0, zIndex:100, boxShadow:C.card2 }}>
        <Logo C={C} />
        <nav style={{ display:"flex", gap:2 }}>
          {[["dashboard", lang==="es"?"Panel":"Dashboard"], ["portfolio", lang==="es"?"Portafolio":"Portfolio"]].map(([key, label]) => (
            <button key={key} className="ntab" onClick={() => setTab(key)}
              style={{ padding:"5px 14px", fontSize:12.5, fontWeight:tab===key?600:400, color:tab===key?C.accent:C.subtle, background:tab===key?C.accentBg:"transparent", borderRadius:6 }}>
              {label}
            </button>
          ))}
        </nav>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <div style={{ display:"flex", alignItems:"center", gap:5 }}>
            <div style={{ width:5, height:5, borderRadius:"50%", background:statusColor }} className={wsStatus==="live"?"pulse":""} />
            <span style={{ fontSize:9, color:statusColor, fontFamily:"'DM Mono'", letterSpacing:0.8, whiteSpace:"nowrap" }}>{statusLabel}</span>
          </div>
          <button className="hbtn" onClick={() => setLang(l => l==="es"?"en":"es")}
            style={{ padding:"3px 10px", fontSize:11, fontWeight:600, color:C.accent, border:`1px solid ${C.border}`, borderRadius:6 }}>
            {lang === "es" ? "EN" : "ES"}
          </button>
          <button className="hbtn" onClick={() => setDark(d => !d)}
            style={{ padding:"3px 10px", fontSize:11, color:C.text, border:`1px solid ${C.border}`, borderRadius:6 }}>
            {dark ? "☀ Claro" : "◑ Oscuro"}
          </button>
          <button className="hbtn mobham" onClick={() => setMobileOpen(true)}
            style={{ fontSize:18, color:C.text, display:"none", alignItems:"center" }}>☰</button>
        </div>
      </header>

      {/* Layout */}
      <div style={{ display:"flex", height:"calc(100dvh - 56px)" }}>
        <aside className="dsidebar" style={{ width:252, borderRight:`1px solid ${C.border}`, overflowY:"auto", background:C.surface, flexShrink:0 }}>
          <SidebarContent />
        </aside>

        <main className="main" style={{ flex:1, overflowY:"auto", padding:"24px 26px" }}>

          {tab === "dashboard" && (
            <>
              {/* Hero */}
              <div style={{ marginBottom:22 }}>
                <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8, flexWrap:"wrap" }}>
                  <span style={{ fontSize:22 }}>{asset.icon}</span>
                  <div>
                    <div style={{ fontSize:10, color:C.subtle, letterSpacing:1.5, textTransform:"uppercase", fontWeight:600, marginBottom:2 }}>
                      {asset.name} · {wsStatus==="live"?"Binance WebSocket":wsStatus==="sim"?(lang==="es"?"Simulado":"Sim"):(lang==="es"?"Conectando…":"Connecting…")}
                    </div>
                    <div style={{ fontFamily:"'Libre Baskerville'", fontWeight:700, fontSize:"clamp(26px,4vw,40px)", color:C.heading, letterSpacing:-0.5, lineHeight:1.1 }}>
                      {!ticker ? "—" : "$" + fmt(price, dp)}
                    </div>
                  </div>
                  {ticker && (
                    <div style={{ paddingBottom:4 }}>
                      <span style={{ fontFamily:"'DM Mono'", fontSize:15, fontWeight:600, color:isUp?C.long:C.short }}>
                        {isUp ? "+" : ""}{ch24.toFixed(2)}%
                      </span>
                      <span style={{ fontSize:10, color:C.subtle, marginLeft:6 }}>24h</span>
                    </div>
                  )}
                </div>

                {/* KPI strip */}
                {ticker && (
                  <div className="kpigrid" style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:10, marginBottom:20 }}>
                    {[
                      { label:lang==="es"?"Máx 24h":"24h High", value:`$${fmt(ticker.high24,dp)}`, color:C.long },
                      { label:lang==="es"?"Mín 24h":"24h Low",  value:`$${fmt(ticker.low24,dp)}`,  color:C.short },
                      { label:lang==="es"?"Volumen":"Volume",    value:`$${fmt(ticker.vol24/1e6,1)}M`, color:C.text },
                      { label:"RSI (14)", value:rsi?rsi.toFixed(1):"—", color:rsi>70?C.short:rsi<30?C.long:C.text },
                      { label:"MACD",     value:macd.macd!=null?(macd.macd>0?"+":"")+macd.macd.toFixed(4):"—", color:macd.macd>0?C.long:C.short },
                    ].map((k, i) => (
                      <div key={i} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:10, padding:"10px 14px", boxShadow:C.card2 }}>
                        <div style={{ fontSize:9, color:C.subtle, letterSpacing:1, textTransform:"uppercase", marginBottom:3, fontWeight:600 }}>{k.label}</div>
                        <div style={{ fontFamily:"'DM Mono'", fontSize:14, fontWeight:700, color:k.color }}>{k.value}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Charts */}
              {klines.length > 0 && (
                <div className="chartgrid" style={{ display:"grid", gridTemplateColumns:"2fr 1fr", gap:14, marginBottom:16 }}>
                  <Card title={`${asset.label} · 1H · ${klines.length} ${lang==="es"?"velas":"candles"}`} C={C}>
                    <ResponsiveContainer width="100%" height={165}>
                      <AreaChart data={klines} margin={{ top:4, right:8, bottom:0, left:-14 }}>
                        <defs>
                          <linearGradient id="pg" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%"   stopColor={isUp?C.long:C.short} stopOpacity={dark?0.28:0.18} />
                            <stop offset="100%" stopColor={isUp?C.long:C.short} stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="2 5" stroke={C.border} vertical={false} />
                        <XAxis dataKey="time" tick={{ fontSize:8, fill:C.subtle }} tickLine={false} interval={Math.floor(klines.length/6)} />
                        <YAxis domain={["auto","auto"]} tick={{ fontSize:8, fill:C.subtle }} tickLine={false}
                          tickFormatter={v => "$" + (v >= 1000 ? fmt(v,0) : fmt(v, dp > 2 ? dp : 2))} width={64} />
                        <Tooltip content={<CTip C={C} isPrice dp={dp} />} />
                        {signal?.entry      && <ReferenceLine y={signal.entry}      stroke={C.accent} strokeDasharray="4 3" strokeWidth={1} label={{ value:"Entry", fill:C.accent, fontSize:8, position:"right" }} />}
                        {signal?.stopLoss   && <ReferenceLine y={signal.stopLoss}   stroke={C.short}  strokeDasharray="3 3" strokeWidth={1} label={{ value:"SL",    fill:C.short,  fontSize:8, position:"right" }} />}
                        {signal?.takeProfit && <ReferenceLine y={signal.takeProfit} stroke={C.long}   strokeDasharray="3 3" strokeWidth={1} label={{ value:"TP",    fill:C.long,   fontSize:8, position:"right" }} />}
                        <Area type="monotone" dataKey="close" stroke={isUp?C.long:C.short} strokeWidth={1.8} fill="url(#pg)" dot={false} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </Card>

                  <Card title={lang==="es"?"Perfil de Volumen":"Volume"} C={C}>
                    <ResponsiveContainer width="100%" height={165}>
                      <BarChart data={klines.slice(-20)} margin={{ top:4, right:4, bottom:0, left:-26 }}>
                        <CartesianGrid strokeDasharray="2 5" stroke={C.border} vertical={false} />
                        <XAxis dataKey="time" tick={{ fontSize:8, fill:C.subtle }} tickLine={false} interval={4} />
                        <YAxis tick={{ fontSize:8, fill:C.subtle }} tickLine={false} tickFormatter={v => (v/1e6).toFixed(0)+"M"} />
                        <Tooltip content={<CTip C={C} />} />
                        <Bar dataKey="volume" fill={C.accentBg} stroke={C.accent} strokeWidth={0.8} radius={[2,2,0,0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </Card>
                </div>
              )}

              {/* Capital & Leverage */}
              <Card title={lang==="es"?"Capital y Apalancamiento":"Capital & Leverage"} C={C}>
                <div style={{ display:"flex", gap:24, flexWrap:"wrap", alignItems:"flex-start" }}>
                  <div style={{ minWidth:180 }}>
                    <div style={{ fontSize:10, color:C.subtle, marginBottom:6, fontWeight:500 }}>
                      {lang === "es" ? "Capital (USD)" : "Capital (USD)"}
                    </div>
                    <div style={{ display:"flex", alignItems:"center", background:C.bg, border:`1px solid ${C.border}`, borderRadius:8, overflow:"hidden" }}>
                      <span style={{ padding:"0 12px", fontSize:15, color:C.subtle, fontFamily:"'DM Mono'" }}>$</span>
                      <input type="number" value={capInput} min="1"
                        onChange={e => setCapInput(e.target.value)}
                        onBlur={() => { const v = parseFloat(capInput); if (!isNaN(v) && v > 0) setCapital(v); }}
                        style={{ flex:1, background:"transparent", border:"none", padding:"10px 10px 10px 0", fontSize:15, fontFamily:"'DM Mono'", fontWeight:700, color:C.heading }} />
                    </div>
                    {leverage && (
                      <div style={{ marginTop:7, fontSize:11, color:C.subtle, lineHeight:1.7 }}>
                        <span style={{ color:C.text }}>{lang==="es"?"Posición efectiva: ":"Effective position: "}</span>
                        <span style={{ fontFamily:"'DM Mono'", color:C.accent, fontWeight:700 }}>${fmt(capital * leverage, 0)}</span><br />
                        <span style={{ color:C.text }}>{lang==="es"?"Pérdida máxima: ":"Max loss: "}</span>
                        <span style={{ fontFamily:"'DM Mono'", color:C.short, fontWeight:700 }}>${fmt(capital, 0)}</span>
                        {leverage >= 20 && <><br /><span style={{ color:C.short, fontWeight:700 }}>⚠ {lang==="es"?"Alto riesgo":"High risk"}</span></>}
                      </div>
                    )}
                  </div>
                  <div style={{ flex:1, minWidth:240 }}>
                    <div style={{ fontSize:10, color:C.subtle, marginBottom:6, fontWeight:500 }}>
                      {lang === "es" ? "Apalancamiento" : "Leverage"}
                      {signal?.leverage && (
                        <span style={{ marginLeft:8, color:C.long, fontWeight:600, fontSize:10 }}>
                          ← IA {lang==="es"?"recomienda":"recommends"} {signal.leverage}x
                        </span>
                      )}
                    </div>
                    <div className="levrow" style={{ display:"flex", gap:6 }}>
                      {LEVERAGE_OPS.map(l => {
                        const isAI  = signal?.leverage === l;
                        const isSel = leverage === l;
                        return (
                          <button key={l} className="levbtn" onClick={() => setLeverage(l)}
                            style={{ flex:1, minWidth:36, padding:"8px 0", fontSize:11, fontWeight:700, borderRadius:8,
                              background: isSel ? (isAI ? C.long : C.accent) : isAI ? `${C.long}18` : C.bg,
                              color: isSel ? "#fff" : isAI ? C.long : C.subtle,
                              border: `1.5px solid ${isSel ? (isAI ? C.long : C.accent) : isAI ? C.long+"55" : C.border}` }}>
                            {l}x
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </Card>

              {/* AI Controls */}
              <div style={{ display:"flex", gap:10, margin:"14px 0", flexWrap:"wrap" }}>
                <button className="aibtn" onClick={runSignal} disabled={analyzing || !ticker}
                  style={{ flex:1, minWidth:200, padding:"13px 22px", background:C.accent, borderRadius:10, color:"#fff", fontSize:13.5, fontWeight:600, boxShadow:`0 4px 18px ${C.accent}40`, display:"flex", alignItems:"center", justifyContent:"center", gap:10 }}>
                  {analyzing
                    ? <><div className="spin" style={{ width:14, height:14, border:"2px solid rgba(255,255,255,0.35)", borderTopColor:"#fff", borderRadius:"50%" }} />{lang==="es"?"ARIA Analizando…":"ARIA Analyzing…"}</>
                    : <><span style={{ fontSize:16 }}>✦</span>{lang==="es"?"Ejecutar Señal ARIA":"Run ARIA Signal"}</>
                  }
                </button>
                <button className="hbtn" onClick={() => setAutoOn(a => !a)}
                  style={{ padding:"12px 16px", borderRadius:10, border:`1.5px solid ${autoOn?C.long:C.border}`, background:autoOn?`${C.long}12`:C.card, color:autoOn?C.long:C.subtle, fontSize:12, fontWeight:600, cursor:"pointer" }}>
                  {autoOn
                    ? <><span className="blink">●</span> Auto {fmtCD(countdown)}</>
                    : <>⏱ {lang==="es"?"Auto Horario":"Hourly Auto"}</>
                  }
                </button>
              </div>

              {/* Signal card */}
              {signal && !signal.error && (
                <div className="fade" style={{ background:C.card, border:`1.5px solid ${sigColor(signal.signal)}40`, borderRadius:14, padding:"22px 24px", boxShadow:C.shadow }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:18, flexWrap:"wrap", gap:12 }}>
                    <div>
                      <div style={{ fontSize:9, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:C.subtle, marginBottom:6 }}>
                        ARIA · {signal.asset} · {signal.time}
                      </div>
                      <div style={{ display:"flex", alignItems:"center", gap:10, flexWrap:"wrap" }}>
                        <span style={{ fontFamily:"'Libre Baskerville'", fontWeight:700, fontSize:30, color:sigColor(signal.signal), letterSpacing:-0.5, lineHeight:1 }}>
                          {signal.signal}
                        </span>
                        <Chip label={`${signal.confidence}% conf.`} color={sigColor(signal.signal)} C={C} />
                        <Chip label={`${signal.leverage}x`} color={C.accent} C={C} />
                        <Chip label={signal.marketStructure} color={C.text} C={C} />
                      </div>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <div style={{ fontSize:9, color:C.subtle, textTransform:"uppercase", letterSpacing:1, marginBottom:3 }}>R/R Ratio</div>
                      <div style={{ fontFamily:"'Libre Baskerville'", fontSize:20, fontWeight:700, color:C.heading }}>1 : {fmt(signal.riskRewardRatio, 2)}</div>
                    </div>
                  </div>

                  <div className="siggrid" style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:10, marginBottom:20 }}>
                    {[
                      { label:lang==="es"?"Entrada":"Entry",   value:`$${fmt(signal.entry,dp)}`,      color:C.accent },
                      { label:"Stop Loss",                      value:`$${fmt(signal.stopLoss,dp)}`,   color:C.short  },
                      { label:"Take Profit",                    value:`$${fmt(signal.takeProfit,dp)}`, color:C.long   },
                      { label:lang==="es"?"% Riesgo":"Risk %", value:`${signal.capitalToRisk}%`,      color:C.wait   },
                    ].map((m, i) => (
                      <div key={i} style={{ background:C.bg, borderRadius:10, padding:"11px 14px", border:`1px solid ${C.border}` }}>
                        <div style={{ fontSize:9, color:C.subtle, letterSpacing:1, textTransform:"uppercase", marginBottom:3, fontWeight:600 }}>{m.label}</div>
                        <div style={{ fontFamily:"'DM Mono'", fontSize:14, fontWeight:700, color:m.color }}>{m.value}</div>
                      </div>
                    ))}
                  </div>

                  <p style={{ fontFamily:"'Libre Baskerville'", fontStyle:"italic", fontSize:13.5, color:C.text, lineHeight:1.8, marginBottom:16 }}>{signal.summary}</p>

                  {signal.technicalBasis && (
                    <div style={{ background:C.bg, borderRadius:9, padding:"12px 16px", marginBottom:12, border:`1px solid ${C.border}` }}>
                      <div style={{ fontSize:9, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:C.subtle, marginBottom:5 }}>
                        {lang==="es"?"Base Técnica":"Technical Basis"}
                      </div>
                      <p style={{ fontSize:12.5, color:C.text, lineHeight:1.65 }}>{signal.technicalBasis}</p>
                    </div>
                  )}

                  {signal.keyLevels?.length > 0 && (
                    <div style={{ marginBottom:14 }}>
                      <div style={{ fontSize:9, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:C.subtle, marginBottom:8 }}>
                        {lang==="es"?"Niveles Clave":"Key Levels"}
                      </div>
                      <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                        {signal.keyLevels.map((lv, i) => (
                          <span key={i} style={{ padding:"3px 12px", background:C.accentBg, border:`1px solid ${C.border}`, borderRadius:20, fontSize:11, fontFamily:"'DM Mono'", color:C.text }}>{lv}</span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div style={{ background:C.accentBg, borderRadius:9, padding:"12px 16px", marginBottom:12, border:`1px solid ${C.accent}30` }}>
                    <div style={{ fontSize:9, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:C.accent, marginBottom:5 }}>
                      {lang==="es"?"Justificación Apalancamiento":"Leverage Rationale"} — {signal.leverage}x
                    </div>
                    <p style={{ fontSize:12.5, color:C.text, lineHeight:1.65 }}>{signal.leverageRationale}</p>
                  </div>

                  {signal.learningNote && (
                    <div style={{ background:`${C.long}0d`, borderRadius:9, padding:"12px 16px", marginBottom:12, border:`1px solid ${C.long}28` }}>
                      <div style={{ fontSize:9, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:C.long, marginBottom:5 }}>
                        {lang==="es"?"Aprendizaje del Agente":"Agent Learning"}
                      </div>
                      <p style={{ fontSize:12.5, color:C.text, lineHeight:1.65 }}>{signal.learningNote}</p>
                    </div>
                  )}

                  {signal.warning && (
                    <div style={{ borderTop:`1px solid ${C.border}`, paddingTop:14, display:"flex", gap:9, alignItems:"flex-start", marginBottom:14 }}>
                      <span style={{ color:C.wait, fontSize:15, flexShrink:0 }}>⚠</span>
                      <p style={{ fontSize:12.5, color:C.subtle, lineHeight:1.65 }}>{signal.warning}</p>
                    </div>
                  )}

                  <div style={{ padding:"10px 14px", background:`${C.short}08`, border:`1px solid ${C.short}20`, borderRadius:8, fontSize:10, color:C.subtle, lineHeight:1.65 }}>
                    ⚠ {lang==="es"
                      ? "Las señales de ARIA son únicamente informativas. No constituyen asesoría financiera. El trading con apalancamiento conlleva riesgo significativo de pérdida de capital."
                      : "ARIA signals are for informational purposes only. Not financial advice. Leveraged trading carries significant risk of capital loss."}
                  </div>
                </div>
              )}

              {signal?.error && (
                <div style={{ marginTop:14, background:`${C.short}0a`, border:`1px solid ${C.short}30`, borderRadius:10, padding:"14px 18px", color:C.short, fontSize:13 }}>
                  {lang==="es"?"Error al generar señal. Verifica tu conexión.":"Failed to generate signal. Check your connection."}
                </div>
              )}
            </>
          )}

          {tab === "portfolio" && (
            <div className="fade">
              <h2 style={{ fontFamily:"'Libre Baskerville'", fontSize:20, fontWeight:700, color:C.heading, marginBottom:6 }}>
                {lang === "es" ? "Portafolio" : "Portfolio"}
              </h2>
              <p style={{ fontSize:12.5, color:C.subtle, marginBottom:22, lineHeight:1.6 }}>
                {lang==="es"?"Historial de señales ARIA ejecutadas en esta sesión.":"ARIA signal history for this session."}
              </p>
              {history.length === 0 ? (
                <div style={{ textAlign:"center", padding:"48px 24px" }}>
                  <div style={{ fontSize:32, marginBottom:12 }}>📊</div>
                  <div style={{ fontFamily:"'Libre Baskerville'", fontSize:17, color:C.heading, marginBottom:8 }}>
                    {lang==="es"?"Sin posiciones aún":"No positions yet"}
                  </div>
                  <p style={{ fontSize:12.5, color:C.subtle }}>
                    {lang==="es"?"Ejecuta señales de ARIA para ver el historial.":"Run ARIA signals to see history."}
                  </p>
                </div>
              ) : [...history].reverse().map((s, i) => (
                <div key={i} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:12, padding:"16px 20px", boxShadow:C.card2, marginBottom:12 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10, flexWrap:"wrap", gap:8 }}>
                    <div>
                      <div style={{ fontSize:9, color:C.subtle, letterSpacing:1, textTransform:"uppercase", marginBottom:4 }}>{s.asset} · {s.time}</div>
                      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                        <span style={{ fontFamily:"'Libre Baskerville'", fontSize:18, fontWeight:700, color:sigColor(s.signal) }}>{s.signal}</span>
                        <span style={{ fontFamily:"'DM Mono'", fontSize:11, color:C.subtle }}>{s.leverage}x · {s.confidence}%</span>
                      </div>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <div style={{ fontSize:9, color:C.subtle, marginBottom:2 }}>{lang==="es"?"Precio entrada":"Entry price"}</div>
                      <div style={{ fontFamily:"'DM Mono'", fontSize:15, fontWeight:700, color:C.heading }}>${s.priceAtSignal}</div>
                    </div>
                  </div>
                  <div style={{ display:"flex", gap:16, flexWrap:"wrap", marginBottom:8 }}>
                    {[
                      { label:"SL",  value:`$${fmt(s.stopLoss,dp)}`,        color:C.short },
                      { label:"TP",  value:`$${fmt(s.takeProfit,dp)}`,      color:C.long  },
                      { label:"R/R", value:`1:${fmt(s.riskRewardRatio,1)}`, color:C.text  },
                      { label:lang==="es"?"Riesgo":"Risk", value:`${s.capitalToRisk}%`, color:C.wait },
                    ].map((k, j) => (
                      <span key={j} style={{ fontSize:11, color:C.subtle }}>
                        <span style={{ fontWeight:600 }}>{k.label}: </span>
                        <span style={{ fontFamily:"'DM Mono'", color:k.color, fontWeight:600 }}>{k.value}</span>
                      </span>
                    ))}
                  </div>
                  <p style={{ fontSize:12, color:C.subtle, lineHeight:1.5, fontStyle:"italic" }}>{s.summary?.slice(0,140)}…</p>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────
function Logo({ C }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
      <div style={{ width:30, height:30, background:C.accent, borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
        <span style={{ color:"#fff", fontFamily:"'Libre Baskerville'", fontWeight:700, fontSize:14 }}>A</span>
      </div>
      <div>
        <div style={{ fontFamily:"'Libre Baskerville'", fontWeight:700, fontSize:14, color:C.heading, letterSpacing:0.3 }}>ARIA</div>
        <div style={{ fontSize:9, color:C.subtle, letterSpacing:1.8, textTransform:"uppercase" }}>AI Trading Agent</div>
      </div>
    </div>
  );
}

function Card({ title, children, C, extra }) {
  return (
    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:12, padding:"14px 18px", boxShadow:C.card2, marginBottom:14 }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
        <span style={{ fontSize:9, fontWeight:600, letterSpacing:1.5, textTransform:"uppercase", color:C.subtle }}>{title}</span>
        {extra}
      </div>
      {children}
    </div>
  );
}

function Chip({ label, color, C }) {
  return (
    <span style={{ padding:"3px 12px", borderRadius:6, background:`${color}15`, border:`1px solid ${color}40`, fontSize:11, fontWeight:600, color, fontFamily:"'DM Mono'" }}>
      {label}
    </span>
  );
}
